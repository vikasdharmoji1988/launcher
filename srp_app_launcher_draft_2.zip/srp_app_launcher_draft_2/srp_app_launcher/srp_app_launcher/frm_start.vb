﻿Imports System.IO

Public Class frm_start
    Private Sub frm_start_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '###########################################################
        'step-additional software added
        Dim folder_list As List(Of String)
        folder_list = New List(Of String)

        Call Getfirstlevelsubfolder(global_variable.base_folder_path & "\OTHER", folder_list)

        Dim i
        If folder_list.Count > 0 Then
            For i = 0 To folder_list.Count - 1
                chl_additional_software.Items.Add(folder_list.Item(i))
            Next
        End If
        '##############################################################
        'step-add in treeviews
        tv_folder.HideSelection = False
        tv_folder.FullRowSelect = True
        Dim rootPath As String = global_variable.base_folder_path  'your main folder path

        'tv_folder.Nodes.Clear()

        Dim rootDir As New DirectoryInfo(rootPath)

        Dim rootNode As TreeNode = tv_folder.Nodes.Add(rootDir.Name)
        rootNode.Tag = rootDir.FullName

        LoadSubDirectories(rootDir, rootNode)


        tv_folder.Focus()
    End Sub
    Private Sub LoadSubDirectories(dir As DirectoryInfo, parentNode As TreeNode)


        Dim directories() As DirectoryInfo

        Try
            directories = dir.GetDirectories()
        Catch ex As Exception
            ' Skip this folder but DO NOT stop entire recursion
            Exit Sub
        End Try

        Dim allowedFolders As New List(Of String) From {"NX", "CATIAV5"}

        For Each subDir As DirectoryInfo In directories

            ' ✅ Only filter at ROOT
            If parentNode.Level = 0 Then
                If Not allowedFolders.Contains(subDir.Name.ToUpper()) Then
                    Continue For
                End If
            End If
            If parentNode.Level >= 3 Then
                Continue For
            End If
            Dim childNode As TreeNode = parentNode.Nodes.Add(subDir.Name)
            childNode.Tag = subDir.FullName

            ' ✅ Try loading deeper even if some fail
            Try
                LoadSubDirectories(subDir, childNode)
            Catch ex As Exception
                ' Skip problematic subfolder but continue others
            End Try

        Next
    End Sub

    Private Sub tv_folder_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles tv_folder.AfterSelect
        global_variable.selected_node_tag = e.Node.Tag.ToString
        Dim x_string As String = ""
        x_string = Replace(global_variable.selected_node_tag, global_variable.base_folder_path & "\", "", 1, -1, CompareMethod.Text)
        Dim str_of_app() As String
        Erase str_of_app
        str_of_app = Split(x_string, "\", -1, CompareMethod.Text)
        Dim type_of_app As String = ""
        type_of_app = str_of_app(0)
        If IO.Directory.Exists(global_variable.selected_node_tag & "\CatENV") = True Then
            Dim env_variable As Dictionary(Of String, String)
            If IsNothing(env_variable) = False Then
                env_variable.Clear()
            End If

            env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)

            Dim txt_file_path As String = global_variable.base_folder_path & "\CONFIG\Binaries.txt"
            Call ReadKeyValuesFromTextFile(txt_file_path, env_variable)

            Dim key_env_for_license As String = Split(global_variable.selected_node_tag, "\", -1, CompareMethod.Text)(UBound(Split(global_variable.selected_node_tag, "\", -1, CompareMethod.Text)))
            Dim license_list() As String
            Erase license_list
            If LCase(type_of_app) = LCase("catiav5") Then
                If IsNothing(env_variable("catia_license_list")) = False Then
                    license_list = Split(env_variable("catia_license_list"), ",", -1, CompareMethod.Text)
                End If
            End If

            'Dim txt_file_path As String = global_variable.selected_node_tag & "\license_configuration.txt"
            'Dim lines_list As List(Of String)
            'lines_list = New List(Of String)
            'lines_list.Clear()
            'chl_lic_configuration.Items.Clear()
            'ReadTextFileLineByLine(txt_file_path, lines_list)
            If license_list.Length > 0 Then
                For i = LBound(license_list) To UBound(license_list)
                    chl_lic_configuration.Items.Add(license_list(i))
                Next
            End If
        End If


        'If IO.File.Exists(global_variable.selected_node_tag & "\license_configuration.txt") = False Then
        '    chl_lic_configuration.Items.Clear()
        'End If

        'If IO.File.Exists(global_variable.selected_node_tag & "\additional_software.txt") = True Then
        '    Dim txt_file_path1 As String = global_variable.selected_node_tag & "\additional_software.txt"
        '    Dim lines_list1 As List(Of String)
        '    lines_list1 = New List(Of String)
        '    lines_list1.Clear()
        '    chl_additional_software.Items.Clear()
        '    ReadTextFileLineByLine(txt_file_path1, lines_list1)
        '    If lines_list1.Count > 0 Then
        '        For i = 0 To lines_list1.Count - 1
        '            chl_additional_software.Items.Add(lines_list1.Item(i))
        '        Next
        '    End If
        'End If
        'If IO.File.Exists(global_variable.selected_node_tag & "\additional_software.txt") = False Then
        '    chl_additional_software.Items.Clear()
        'End If

        'tv_folder.Focus()
    End Sub

    Private Sub tv_folder_BeforeExpand(sender As Object, e As TreeViewCancelEventArgs) Handles tv_folder.BeforeExpand
        Dim node As TreeNode = e.Node


        node.Nodes.Clear()

            Dim rootDir As New DirectoryInfo(node.Tag.ToString())
            LoadSubDirectories(rootDir, node)


    End Sub



    Private Sub chl_lic_configuration_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles chl_lic_configuration.ItemCheck
        If e.NewValue = CheckState.Checked Then
            For i As Integer = 0 To chl_lic_configuration.Items.Count - 1
                If i <> e.Index Then
                    chl_lic_configuration.SetItemChecked(i, False)
                End If
            Next
        End If
    End Sub

    Private Sub frm_start_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        tv_folder.Focus()
    End Sub

    Private Sub chl_additional_software_SelectedIndexChanged(sender As Object, e As EventArgs) Handles chl_additional_software.SelectedIndexChanged
        tv_folder.Focus()
    End Sub

    Private Sub chl_lic_configuration_SelectedIndexChanged(sender As Object, e As EventArgs) Handles chl_lic_configuration.SelectedIndexChanged
        tv_folder.Focus()
    End Sub

    Private Sub butt_start_Click(sender As Object, e As EventArgs) Handles butt_start.Click

        If IO.File.Exists(global_variable.selected_node_tag & "\license_configuration.txt") = False Then
            Dim status
            status = MsgBox("Please select at least one environment from the application to start.", vbCritical, "SPR Lanucher")
            Exit Sub
        End If

        If chl_lic_configuration.CheckedItems.Count = 0 Then
            Dim status
            status = MsgBox("Please select at least one license configuration.", vbCritical, "SPR Lanucher")
            Exit Sub
        End If


        Dim bat_file_name As String = ""

        Dim lic_bat_name As String = LCase(Replace(chl_lic_configuration.CheckedItems(0).ToString, "+", "_")) & ".bat"

        Dim bat_file_path As String = global_variable.selected_node_tag & "\" & lic_bat_name
        Call RunBatFile(bat_file_path)

    End Sub
End Class