﻿Public Class frmDebugViewer
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub frmDebugViewer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Icon = My.Resources.LAUNCHER
        PictureBox1.Left = 8
        PictureBox1.Top = 8
        PictureBox1.Width = 36
        PictureBox1.Height = 36
        Label1.Top = 8
        Label1.Left = 45
        Label1.Width = 230 ' adjust based on form
        Label1.Height = 100

        Button1.Top = 110
        Button1.Left = 60
        Button1.Width = 95
        Button1.Height = 36

        Me.Width = 240 + 30
        Me.Height = 190


        'Me.Width = 520
        'Me.Height = 150
        'Me.StartPosition = FormStartPosition.CenterScreen
        'Me.FormBorderStyle = FormBorderStyle.FixedDialog
        'Me.MaximizeBox = False
        'Me.MinimizeBox = False
        'Me.Text = "Launch Debug Viewer"

        Label1.Font = New Font("Segoe UI", 9, FontStyle.Regular)
        Label1.AutoSize = False
        'Label1.Top = 8
        'Label1.Left = 8
        'Label1.Width = 400   ' adjust based on form
        'Label1.Height = 100 ' enough for multiple lines
        Label1.TextAlign = ContentAlignment.TopLeft

        Label1.Text =
    "Customer: " & global_variable.customer_name & vbCrLf &
    "Site: " & global_variable.site_name & vbCrLf &
    "CAD Type: " & global_variable.final_cad_type & vbCrLf &
    "CAD Version: " & global_variable.final_v5_version & vbCrLf &
    "License Selected: " & global_variable.license_selected & vbCrLf &
    "Add-ons: " & global_variable.addon_list



        'Public Shared site_name As String
        'Public Shared customer_name As String
        'Public Shared final_v5_version As String
        'Public Shared final_cad_type As String
        'Public Shared license_selected As String
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class