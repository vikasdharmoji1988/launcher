﻿Public Class global_variable
    Public Shared base_folder_path As String
    Public Shared selected_node_tag As String
    Public Shared site_name As String
    Public Shared customer_name As String
    Public Shared final_v5_version As String
    Public Shared final_cad_type As String
    Public Shared license_selected As String
    Public Shared addon_list As String

End Class
