Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# =====================================================================
# 1. DYNAMIC PATHS & DATA LOADING
# =====================================================================
# Auto-detect the directory of the running .exe file
$exePath   = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
$scriptDir = Split-Path -Path $exePath -Parent
$rootDir   = Split-Path -Path $scriptDir -Parent

# Detect Site for the Window Title
$siteFilePath = "$scriptDir\site.txt"
$siteDisplay  = "DEFAULT"
if (Test-Path $siteFilePath) { $siteDisplay = (Get-Content -Path $siteFilePath -TotalCount 1).Trim().ToUpper() }

$csvPath       = Join-Path -Path $scriptDir -ChildPath "environments.csv"
$addonCsvPath  = Join-Path -Path $scriptDir -ChildPath "addons.csv"
$licenseScript = Join-Path -Path $rootDir -ChildPath "LISENSES\global\$siteDisplay\Licenses.ps1"
$iconDir       = Join-Path -Path $scriptDir -ChildPath "icons"

# Safety check
if (-Not (Test-Path $csvPath) -or -Not (Test-Path $licenseScript)) {
    [System.Windows.Forms.MessageBox]::Show("Missing environments.csv or Licenses.ps1.", "Configuration Error", 0, [System.Windows.Forms.MessageBoxIcon]::Error)
    exit
}

. $licenseScript # Load the Get-CADLicenses function

# Import CSV and filter out any environments where the ExecPath does not exist on this PC
$rawEnvData = Import-Csv -Path $csvPath
$envData = $rawEnvData | Where-Object { 
    (-not [string]::IsNullOrWhiteSpace($_.ExecPath)) -and (Test-Path $_.ExecPath) 
}

if ($null -eq $envData -or $envData.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("No valid CAD installations found on this computer.", "No Environments", 0, [System.Windows.Forms.MessageBoxIcon]::Warning)
    exit
}

$addonData = if (Test-Path $addonCsvPath) { Import-Csv -Path $addonCsvPath } else { @() }
$availableLicenses = Get-CADLicenses

# =====================================================================
# 2. MAIN UI & WINDOW SETUP
# =====================================================================
<# Detect Site for the Window Title
$siteFilePath = "$scriptDir\site.txt"
$siteDisplay  = "DEFAULT"
if (Test-Path $siteFilePath) { $siteDisplay = (Get-Content -Path $siteFilePath -TotalCount 1).Trim().ToUpper() } #>

$form = New-Object System.Windows.Forms.Form
$form.Text = "SPR TECH - CAD Launcher [Site: $siteDisplay]"
$form.Size = New-Object System.Drawing.Size(700, 580)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "Sizable" 
$form.Font = New-Object System.Drawing.Font("Segoe UI", 12) 

# --- IMAGE LIST SETUP ---
$imageList = New-Object System.Windows.Forms.ImageList
$imageList.ImageSize = New-Object System.Drawing.Size(16, 16)
$imageList.ColorDepth = [System.Windows.Forms.ColorDepth]::Depth32Bit

function Load-IconOrDefault ($Path, $FallbackColor) {
    if (Test-Path $Path) { return [System.Drawing.Image]::FromFile($Path) } 
    else {
        $bmp = New-Object System.Drawing.Bitmap(16, 16)
        $gfx = [System.Drawing.Graphics]::FromImage($bmp)
        $gfx.FillRectangle((New-Object System.Drawing.SolidBrush([System.Drawing.Color]::$FallbackColor)), 0, 0, 16, 16)
        $gfx.Dispose(); return $bmp
    }
}

$imageList.Images.Add("Root", (Load-IconOrDefault "$iconDir\root.png" "Black"))
$imageList.Images.Add("CATIAV5", (Load-IconOrDefault "$iconDir\catia.png" "SteelBlue"))
$imageList.Images.Add("NX", (Load-IconOrDefault "$iconDir\nx.png" "ForestGreen"))
$imageList.Images.Add("Customer", (Load-IconOrDefault "$iconDir\folder.png" "Gold"))
$imageList.Images.Add("Version", (Load-IconOrDefault "$iconDir\file.png" "DimGray"))

# =====================================================================
# 3. SPLIT CONTAINER (Dynamic Layout Manager)
# =====================================================================
$splitContainer = New-Object System.Windows.Forms.SplitContainer
$splitContainer.Location = New-Object System.Drawing.Point(15, 15)
$splitContainer.Size = New-Object System.Drawing.Size(650, 450) 
$splitContainer.Anchor = "Top, Bottom, Left, Right"
$splitContainer.SplitterDistance = 420 

# --------------------------------------------------------
# PANEL 1: TREEVIEW (Left Side)
# --------------------------------------------------------
$grpApp = New-Object System.Windows.Forms.GroupBox
$grpApp.Text = "Application To Start"
$grpApp.Dock = "Fill" 

$treeView = New-Object System.Windows.Forms.TreeView
$treeView.Dock = "Fill"
$treeView.ImageList = $imageList
$treeView.Font = New-Object System.Drawing.Font("Segoe UI", 10) 

$rootNode = $treeView.Nodes.Add("SPR")
$rootNode.ImageKey = "Root"; $rootNode.SelectedImageKey = "Root"

$cadTypes = $envData | Select-Object -ExpandProperty CADType -Unique
foreach ($type in $cadTypes) {
    $typeNode = $rootNode.Nodes.Add($type)
    $typeNode.ImageKey = $type; $typeNode.SelectedImageKey = $type
    
    $customers = $envData | Where-Object CADType -eq $type | Select-Object -ExpandProperty Customer -Unique
    foreach ($cust in $customers) {
        $custNode = $typeNode.Nodes.Add($cust)
        
        $custIconPath = "$iconDir\$cust.png"
        if (Test-Path $custIconPath) {
            if (-not $imageList.Images.ContainsKey($cust)) { $imageList.Images.Add($cust, [System.Drawing.Image]::FromFile($custIconPath)) }
            $custNode.ImageKey = $cust; $custNode.SelectedImageKey = $cust
        } else {
            $custNode.ImageKey = "Customer"; $custNode.SelectedImageKey = "Customer"
        }
        
        $versions = $envData | Where-Object { $_.CADType -eq $type -and $_.Customer -eq $cust }
        foreach ($ver in $versions) {
            $verNode = $custNode.Nodes.Add($ver.Version)
            $verNode.Tag = $ver
            $verNode.ImageKey = $custNode.ImageKey 
            $verNode.SelectedImageKey = $custNode.SelectedImageKey
        }
    }
}
$rootNode.ExpandAll(); $grpApp.Controls.Add($treeView)
$splitContainer.Panel1.Controls.Add($grpApp)

# --------------------------------------------------------
# PANEL 2: ADDITIONAL SOFTWARE & LICENSES (Right Side)
# --------------------------------------------------------
$grpAddon = New-Object System.Windows.Forms.GroupBox
$grpAddon.Text = "Additional Software"
$grpAddon.Location = New-Object System.Drawing.Point(5, 0)
$grpAddon.Width = $splitContainer.Panel2.ClientSize.Width - 10 
$grpAddon.Height = 140
$grpAddon.Anchor = "Top, Left, Right" 

$script:addonCheckboxes = @()
$yPosAddon = 25
foreach ($item in $addonData) {
    $chk = New-Object System.Windows.Forms.CheckBox
    $chk.Text = $item.DisplayName; $chk.Location = New-Object System.Drawing.Point(10, $yPosAddon)
    $chk.Checked = [System.Convert]::ToBoolean($item.IsDefault)
    $chk.Tag = $item.ConfigValue; $chk.Width = 200
    $grpAddon.Controls.Add($chk); $script:addonCheckboxes += $chk
    $yPosAddon += 25
}

$grpLic = New-Object System.Windows.Forms.GroupBox
$grpLic.Text = "License Configuration"
$grpLic.Location = New-Object System.Drawing.Point(5, 155)
$grpLic.Width = $splitContainer.Panel2.ClientSize.Width - 10
$grpLic.Height = $splitContainer.Panel2.ClientSize.Height - 155
$grpLic.Anchor = "Top, Bottom, Left, Right" 

$script:licenseRadios = @()

function Update-LicenseUI($TargetCADType) {
    $grpLic.Controls.Clear(); $script:licenseRadios = @()
    $filteredLicenses = $availableLicenses | Where-Object CADType -eq $TargetCADType
    $yPos = 25
    foreach ($lic in $filteredLicenses) {
        $rad = New-Object System.Windows.Forms.RadioButton 
        $rad.Text = $lic.DisplayName; $rad.Location = New-Object System.Drawing.Point(10, $yPos)
        $rad.Checked = $lic.IsDefault; $rad.Tag = $lic.ConfigValue; $rad.Width = 200
        $grpLic.Controls.Add($rad); $script:licenseRadios += $rad
        $yPos += 25
    }
}

$treeView.Add_AfterSelect({
    if ($null -ne $treeView.SelectedNode.Tag) { Update-LicenseUI $treeView.SelectedNode.Tag.CADType } 
    else { $grpLic.Controls.Clear() }
})

$splitContainer.Panel2.Controls.Add($grpAddon)
$splitContainer.Panel2.Controls.Add($grpLic)
$form.Controls.Add($splitContainer)

# =====================================================================
# 4. COMPANY LOGO & START BUTTON (Footer Area)
# =====================================================================
$logoPath = "$iconDir\spr.png"
if (Test-Path $logoPath) {
    $picLogo = New-Object System.Windows.Forms.PictureBox
    $picLogo.Size = New-Object System.Drawing.Size(180, 45) 
    $picLogo.Location = New-Object System.Drawing.Point(15, 480) 
    $picLogo.Image = [System.Drawing.Image]::FromFile($logoPath)
    $picLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom 
    $picLogo.Anchor = "Bottom, Left" 
    $form.Controls.Add($picLogo)
}

$btnStart = New-Object System.Windows.Forms.Button
$btnStart.Text = "START"
$btnStart.Size = New-Object System.Drawing.Size(140, 45)
$btnStart.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$btnStart.BackColor = [System.Drawing.Color]::LightSteelBlue

$centerX = ($form.ClientSize.Width - $btnStart.Width) / 2
$btnStart.Location = New-Object System.Drawing.Point($centerX, 480)
$btnStart.Anchor = "Bottom" 

$form.Add_Resize({ $btnStart.Left = ($form.ClientSize.Width - $btnStart.Width) / 2 })

$btnStart.Add_Click({
    $selected = $treeView.SelectedNode
    
    if ($null -eq $selected -or $null -eq $selected.Tag) {
        [System.Windows.Forms.MessageBox]::Show("Please select a specific Version to launch.", "Warning", 0, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }

    $data = $selected.Tag 
    
    $selectedLicense = $script:licenseRadios | Where-Object Checked | ForEach-Object { 
        $tag = $_.Tag
        $availableLicenses | Where-Object ConfigValue -eq $tag
    } | Select-Object -First 1
    
    $activeLicenses = if ($null -ne $selectedLicense) { $selectedLicense.ConfigValue } else { "None" }
    $activeAddons = @($script:addonCheckboxes | Where-Object Checked | ForEach-Object Tag)
    $addonString = if ($activeAddons.Count -gt 0) { $activeAddons -join " & " } else { "None" }

    # --- LOCAL TEMP ENV FILE ---
    $tempDir = "C:\temp"
    if (-Not (Test-Path $tempDir)) { New-Item -ItemType Directory -Path $tempDir -Force | Out-Null }
    
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $safeTime = Get-Date -Format 'yyyyMMdd_HHmmss'
    
    $envFilePath = Join-Path -Path $tempDir -ChildPath "CAD_Session.txt"
    # Added HOSTNAME below
    @("HOSTNAME=$env:COMPUTERNAME", "USERNAME=$env:USERNAME", "LAUNCH_TIME=$timestamp", "CAD_SYSTEM=$($data.CADType)", "CUSTOMER=$($data.Customer)", "VERSION=$($data.Version)", "SITE=$siteDisplay") | Set-Content -Path $envFilePath

    # --- NETWORK LOGGING ---
    $logDir = "$rootDir\TEMP"
    if (-Not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
    $logPath = "$logDir\CAD_Launcher_Log_$safeTime.txt" 
    
    try {
        # Added Hostname to the CSV Header
        if (-Not (Test-Path -Path $logPath)) { Add-Content $logPath "Timestamp,Hostname,Username,Site,CAD_Type,Customer,Version,Licenses,AddOns" -ErrorAction Stop }
        
        # Added $env:COMPUTERNAME to the data row
        Add-Content $logPath "$timestamp,$env:COMPUTERNAME,$env:USERNAME,$siteDisplay,$($data.CADType),$($data.Customer),$($data.Version),`"$activeLicenses`",`"$addonString`"" -ErrorAction Stop
    } catch { Write-Warning "Network logging bypassed." }

    # --- EXECUTION ---
    $launchMessage = "Ready to Launch: $($data.Customer) - $($data.Version)`nSite: $siteDisplay`nCAD Type: $($data.CADType)`nLicenses: $activeLicenses`nAdd-ons: $addonString`n"

    if ($data.CADType -eq "CATIAV5") {
        
        if ($null -ne $selectedLicense -and $null -ne $selectedLicense.CATSettingsPath) {
            $userSettingsDir = "C:\Users\$env:USERNAME\SPR_CatiaV5\CATSettings\$($data.Customer)"
            
            if (-Not (Test-Path -Path $userSettingsDir)) { New-Item -ItemType Directory -Path $userSettingsDir -Force | Out-Null }

            if (Test-Path $selectedLicense.CATSettingsPath) {
                Copy-Item -Path $selectedLicense.CATSettingsPath -Destination "$userSettingsDir\Licensing.CATSettings" -Force
                $launchMessage += "`nCopied License Settings: $($selectedLicense.DisplayName)"
            } else {
                $launchMessage += "`nWARNING: Could not find network License settings file!"
            }
            
            $env:DSLS_CONFIG = $selectedLicense.LicenseServer
        }

        if ($activeAddons -contains "QCHECKER") {
            $env:QCHECKER_DIR = "$rootDir\OTHER\QChecker"
            $env:PATH = "$env:QCHECKER_DIR\bin;" + $env:PATH
            $env:CATDictionaryPath = if ($env:CATDictionaryPath) { "$env:QCHECKER_DIR\dict;" + $env:CATDictionaryPath } else { "$env:QCHECKER_DIR\dict" }
            $env:CATGraphicPath = if ($env:CATGraphicPath) { "$env:QCHECKER_DIR\graphic;" + $env:CATGraphicPath } else { "$env:QCHECKER_DIR\graphic" }
        }
        
        $arg = "-run `"CNEXT.exe`" -env $($data.EnvName) -direnv `"$($data.EnvDir)`""
        $launchMessage += "`nCommand: $($data.ExecPath) $arg"
        
        # Uncomment below to make it live
        Start-Process -FilePath $data.ExecPath -ArgumentList $arg
    } 
    elseif ($data.CADType -eq "NX") {
        if ($null -ne $selectedLicense) {
            $env:UGS_LICENSE_SERVER = $selectedLicense.LicenseServer
            if (![string]::IsNullOrEmpty($activeLicenses)) { $env:UGS_LICENSE_BUNDLE = $activeLicenses }
        } else {
            $env:UGS_LICENSE_SERVER = $data.LicenseServer 
        }

        $launchMessage += "`nCommand: $($data.ExecPath)\UGII\ugraf.exe -nx`nServer: $env:UGS_LICENSE_SERVER`nBundle: $env:UGS_LICENSE_BUNDLE"
        
        # Uncomment below to make it live
        # Start-Process -FilePath "$($data.ExecPath)\UGII\ugraf.exe" -ArgumentList "-nx"
    }

    [System.Windows.Forms.MessageBox]::Show($launchMessage, "Launch Debug Viewer", 0, [System.Windows.Forms.MessageBoxIcon]::Information)
})

$form.Controls.Add($btnStart)
[void]$form.ShowDialog()