@echo off
title Launching Siemens NX

echo Setting up NX Environment...

:: --------------------------------------------------------
:: USER CONFIGURATION SECTION
:: --------------------------------------------------------

:: 1. Set the Base Directory (Where NX is installed)
set UGII_BASE_DIR=C:\Program Files\Siemens\NX2306

:: 2. Set the Root Directory (Usually the \UGII folder inside Base)
set UGII_ROOT_DIR=%UGII_BASE_DIR%\UGII

:: 3. Set the License Server (Update '28000@your_server_name')
set UGS_LICENSE_SERVER=28000@localhost


:: Set License bundle
set UGS_LICENSE_BUNDLE=ACD10

:: 4. (Optional) Set a custom Customer Defaults or Site file path
:: set UGII_SITE_DIR=C:\YourCompany\NX_Standards

:: --------------------------------------------------------
:: EXECUTION SECTION
:: --------------------------------------------------------

echo Starting NX from %UGII_ROOT_DIR%...

:: Start NX using the 'ugraf.exe' executable
start "NX" "%UGII_ROOT_DIR%\ugraf.exe" -nx

exit