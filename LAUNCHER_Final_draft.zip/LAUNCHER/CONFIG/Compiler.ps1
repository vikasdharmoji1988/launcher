# 1. Tell PowerShell where your folder is
Set-Location -Path "D:\SPR_Launcher_Project\SPR_LAUNCHER"

# 2. Install the Microsoft-approved PS2EXE compiler (if you don't have it yet)
if (-not (Get-Module -ListAvailable -Name ps2exe)) {
    Install-Module -Name ps2exe -Scope CurrentUser -Force
}

# 3. Compile the script into a silent, professional .exe
Invoke-ps2exe -inputFile "SPR_Launcher.ps1" -outputFile "SPR_Launcher.exe" -noConsole -title "SPR CAD Launcher"