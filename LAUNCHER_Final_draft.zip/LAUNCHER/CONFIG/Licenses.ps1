function Get-CADLicenses {
    # Define the root network path where your master CATSettings are stored
    # (Update this to your actual network drive later)
	#LicenseServer = Y:\LAUNCHER\LISENSES\global\pun\DSLicSrv.txt
    $masterSettingsDir = "$scriptDir\CATLicensing"

    return @(
        # --- CATIA Licenses ---
        [PSCustomObject]@{ 
            CADType = "CATIAV5"
            DisplayName = "MD2 - Mechanical Design"
            ConfigValue = "MD2"
            IsDefault = $true
            CATSettingsPath = "$masterSettingsDir\MD2\Licensing.CATSettings"
            LicenseServer = "$rootDir\LISENSES\global\pune\DSLicSrv.txt" 
        },
        [PSCustomObject]@{ 
            CADType = "CATIAV5"
            DisplayName = "MD2 + FS1 (Freestyle)"
            ConfigValue = "MD2+FS1"
            IsDefault = $false
            CATSettingsPath = "$masterSettingsDir\MD2+FS1\Licensing.CATSettings"
            LicenseServer = "$rootDir\LISENSES\global\pune\DSLicSrv.txt" 
        },
		[PSCustomObject]@{ 
            CADType = "CATIAV5"
            DisplayName = "MD2 + GSD"
            ConfigValue = "MD2+GSD"
            IsDefault = $false
            CATSettingsPath = "$masterSettingsDir\MD2+GSD\Licensing.CATSettings"
            LicenseServer = "$rootDir\LISENSES\global\pune\DSLicSrv.txt" 
        },
		[PSCustomObject]@{ 
            CADType = "CATIAV5"
            DisplayName = "MD2+FS1+GSD"
            ConfigValue = "MD2+FS1+GSD"
            IsDefault = $false
            CATSettingsPath = "$masterSettingsDir\MD2+FS1+GSD\Licensing.CATSettings"
            LicenseServer = "$rootDir\LISENSES\global\pune\DSLicSrv.txt" 
        },
		[PSCustomObject]@{ 
            CADType = "CATIAV5"
            DisplayName = "OCS"
            ConfigValue = "OCS"
            IsDefault = $false
            CATSettingsPath = "$masterSettingsDir\OCS\Licensing.CATSettings"
            LicenseServer = "$rootDir\LISENSES\global\pune\DSLicSrv.txt" 
        },
		[PSCustomObject]@{ 
            CADType = "CATIAV5"
            DisplayName = "PCS"
            ConfigValue = "PCS"
            IsDefault = $false
            CATSettingsPath = "$masterSettingsDir\PCS\Licensing.CATSettings"
            LicenseServer = "$rootDir\LISENSES\global\pune\DSLicSrv.txt" 
        },
        
        # --- NX License Bundles ---
        [PSCustomObject]@{ 
            CADType = "NX"
            DisplayName = "Mach 1 Design"
            ConfigValue = "MACH1"
            IsDefault = $true
            CATSettingsPath = $null # NX doesn't use CATSettings
            LicenseServer = "28000@SiemensServer" 
        },
        [PSCustomObject]@{ 
            CADType = "NX"
            DisplayName = "Automotive Bundle"
            ConfigValue = "ACD10"
            IsDefault = $false
            CATSettingsPath = $null 
            LicenseServer = "28000@SiemensServer" 
        }
    )
}