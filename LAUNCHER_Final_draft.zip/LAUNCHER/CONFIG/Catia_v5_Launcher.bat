@echo off
title Launch CATIA

echo.
echo ===============================
echo   Starting CATIA, please wait...
echo ===============================
echo.

:: --------------------------------------------------------
:: VALIDATE ARGUMENTS
:: %1 = CATSTART_PATH
:: %2 = ENV_NAME
:: %3 = ENV_DIR
:: --------------------------------------------------------

if "%~1"=="" (
    echo ERROR: CATSTART_PATH not provided
    exit /b
)

if "%~2"=="" (
    echo ERROR: ENV_NAME not provided
    exit /b
)

if "%~3"=="" (
    echo ERROR: ENV_DIR not provided
    exit /b
)

:: --------------------------------------------------------
:: SET VARIABLES
:: --------------------------------------------------------

set CATSTART_PATH=%~1
set ENV_NAME=%~2
set ENV_DIR=%~3

echo Using:
echo CATSTART_PATH = %CATSTART_PATH%
echo ENV_NAME      = %ENV_NAME%
echo ENV_DIR       = %ENV_DIR%
echo.

echo Launching CATIA...
echo.

:: --------------------------------------------------------
:: EXECUTION
:: --------------------------------------------------------

"%CATSTART_PATH%" -run "CNEXT.exe" -env %ENV_NAME% -direnv "%ENV_DIR%"

exit