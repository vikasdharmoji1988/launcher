﻿Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frm_start
    Private Sub frm_start_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        '##############################################################
        'step-add in treeviews
        tv_folder.HideSelection = False
        tv_folder.FullRowSelect = True
        Dim rootPath As String = global_variable.base_folder_path  'your main folder path

        'tv_folder.Nodes.Clear()

        Dim rootDir As New DirectoryInfo(rootPath)

        Dim rootNode As TreeNode = tv_folder.Nodes.Add(rootDir.Name)
        rootNode.Tag = rootDir.FullName

        LoadSubDirectories(rootDir, rootNode)


        tv_folder.Focus()
    End Sub
    Private Sub LoadSubDirectories(dir As DirectoryInfo, parentNode As TreeNode)


        Dim directories() As DirectoryInfo

        Try
            directories = dir.GetDirectories()
        Catch ex As Exception
            ' Skip this folder but DO NOT stop entire recursion
            Exit Sub
        End Try

        Dim allowedFolders As New List(Of String) From {"NX", "CATIAV5"}

        For Each subDir As DirectoryInfo In directories

            ' ✅ Only filter at ROOT
            If parentNode.Level = 0 Then
                If Not allowedFolders.Contains(subDir.Name.ToUpper()) Then
                    Continue For
                End If
            End If
            If parentNode.Level >= 3 Then
                Continue For
            End If
            Dim childNode As TreeNode = parentNode.Nodes.Add(subDir.Name)
            childNode.Tag = subDir.FullName

            ' ✅ Try loading deeper even if some fail
            Try
                LoadSubDirectories(subDir, childNode)
            Catch ex As Exception
                ' Skip problematic subfolder but continue others
            End Try

        Next
    End Sub

    Private Sub tv_folder_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles tv_folder.AfterSelect
        global_variable.selected_node_tag = e.Node.Tag.ToString
        chl_additional_software.Items.Clear()

        '################################################################
        If tv_folder.SelectedNode.Nodes.Count = 0 Then
            Dim type_app As String = ""
            Call GetAppType(type_app)
            If UCase(type_app) = UCase("CATIAV5") Then
                Call addcatiav5licenselist(global_variable.base_folder_path & "\CONFIG\CATLicensing")

                '###########################################################
                'step-additional software added
                Dim other_folder_list As List(Of String)
                other_folder_list = New List(Of String)
                other_folder_list.Clear()
                Call Getfirstlevelsubfolder(global_variable.base_folder_path & "\OTHER\CATIAV5", other_folder_list)


                If other_folder_list.Count > 0 Then

                    For i = 0 To other_folder_list.Count - 1
                        chl_additional_software.Items.Add(other_folder_list.Item(i))
                    Next
                End If
            End If
        End If




    End Sub

    Private Sub tv_folder_BeforeExpand(sender As Object, e As TreeViewCancelEventArgs) Handles tv_folder.BeforeExpand
        Dim node As TreeNode = e.Node


        node.Nodes.Clear()

        Dim rootDir As New DirectoryInfo(node.Tag.ToString())
        LoadSubDirectories(rootDir, node)


    End Sub



    Private Sub chl_lic_configuration_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles chl_lic_configuration.ItemCheck
        If e.NewValue = CheckState.Checked Then
            For i As Integer = 0 To chl_lic_configuration.Items.Count - 1
                If i <> e.Index Then
                    chl_lic_configuration.SetItemChecked(i, False)
                End If
            Next
        End If
    End Sub

    Private Sub frm_start_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        tv_folder.Focus()
    End Sub

    Private Sub chl_additional_software_SelectedIndexChanged(sender As Object, e As EventArgs) Handles chl_additional_software.SelectedIndexChanged
        tv_folder.Focus()
    End Sub

    Private Sub chl_lic_configuration_SelectedIndexChanged(sender As Object, e As EventArgs) Handles chl_lic_configuration.SelectedIndexChanged
        tv_folder.Focus()
    End Sub

    Private Sub butt_start_Click(sender As Object, e As EventArgs) Handles butt_start.Click


        tv_folder.Focus()
        If tv_folder.SelectedNode.Nodes.Count = 0 Then
            Dim type_app As String = ""
            Call GetAppType(type_app)
            If UCase(type_app) = UCase("CATIAV5") Then

                If chl_lic_configuration.CheckedItems.Count = 0 Then
                    Dim status
                    status = MsgBox("Please select at least one license configuration.", vbCritical, "SPR Lanucher")
                    tv_folder.Focus()
                    Exit Sub
                End If

                If chl_lic_configuration.CheckedItems.Count > 0 Then
                    'step- extract a basic env vriable files
                    Dim env_folder_path As String = global_variable.selected_node_tag & "\CatENV"

                    If IO.Directory.Exists(env_folder_path) = True Then
                        Dim files_list As List(Of String)
                        files_list = New List(Of String)
                        files_list.Clear()
                        GetParticularFilesFromFolder(env_folder_path, "*.txt", files_list)
                        If files_list.Count = 0 Then
                            Dim Status1
                            Dim remaining_folder_path As String = Replace(env_folder_path, global_variable.base_folder_path, "", 1, -1, CompareMethod.Text)
                            Status1 = MsgBox("Env txt( " & remaining_folder_path & "\*.txt" & " )file is not exists.Please contact IT team.", vbCritical, "srp_launcher")
                            Exit Sub
                        End If
                        If files_list.Count > 0 Then
                            Dim base_env_file_txt_file As String
                            base_env_file_txt_file = files_list.Item(0)
                            Dim v5_license_folder_path As String
                            Dim selectedValue As String = chl_lic_configuration.CheckedItems(0).ToString()
                            v5_license_folder_path = global_variable.base_folder_path & "\CONFIG\CATLicensing\" & selectedValue
                            Dim files_list1 As List(Of String)
                            files_list1 = New List(Of String)
                            files_list1.Clear()
                            GetParticularFilesFromFolder(v5_license_folder_path, "*.CATSettings", files_list1)
                            If files_list1.Count = 0 Then
                                Dim Status2
                                Dim remaining_folder_path1 As String = Replace(env_folder_path, global_variable.base_folder_path, "", 1, -1, CompareMethod.Text)
                                Status2 = MsgBox("Catia Licensing( " & remaining_folder_path1 & "\*.CATSettings" & " )file is not exists.Please contact IT team.", vbCritical, "srp_launcher")
                                Exit Sub
                            End If
                            If files_list1.Count > 0 Then
                                Dim v5_license_file_path As String = files_list1.Item(0)
                                CreateCv5EnvFile(base_env_file_txt_file, v5_license_file_path)
                            End If
                        End If
                    End If

                    If IO.Directory.Exists(env_folder_path) = False Then
                        Dim remaining_folder_path As String = Replace(env_folder_path, global_variable.base_folder_path, "", 1, -1, CompareMethod.Text)
                        Dim status
                        status = MsgBox("CatEnv( " & remaining_folder_path & " ) folder is not exists.Please contact IT team.", vbCritical, "srp_launcher")
                        Exit Sub
                    End If

                End If
            End If
        End If

    End Sub
    Public Function addcatiav5licenselist(license_folder As String)
        'Dim licen_folder As String = "C:\VikasData\app_launcher\srp_app_launcher_draft_2\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CONFIG\CATLicensing"
        chl_lic_configuration.Items.Clear()
        Dim license_list As List(Of String)
        license_list = New List(Of String)
        license_list.Clear()
        Call GetFoldersWithLicenseCATSettings(license_folder, license_list)
        If license_list.Count > 0 Then
            For i = 0 To license_list.Count - 1
                chl_lic_configuration.Items.Add(license_list.Item(i))
            Next
        End If
    End Function
    Public Function CreateCv5EnvFile(base_env_txt_file As String, catia_license_setting_path As String)
        Dim base_file_env_variable As Dictionary(Of String, String)
        base_file_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        base_file_env_variable.Clear()
        Call ReadKeyValuesFromTextFile(base_env_txt_file, base_file_env_variable)

        If chl_additional_software.SelectedItems.Count > 0 Then
            Dim i
            For i = 0 To chl_additional_software.SelectedItems.Count - 1
                Dim other_env_file_folder_path As String = ""
                other_env_file_folder_path = global_variable.base_folder_path & "\other\CATIAV5\" & chl_additional_software.SelectedItems.Item(i).ToString
                Dim files_list1 As List(Of String)
                files_list1 = New List(Of String)
                files_list1.Clear()
                GetParticularFilesFromFolder(other_env_file_folder_path, "*.txt", files_list1)
                If files_list1.Count = 0 Then
                    Dim Status2
                    Dim remaining_folder_path1 As String = Replace(other_env_file_folder_path, global_variable.base_folder_path, "", 1, -1, CompareMethod.Text)
                    Status2 = MsgBox(chl_additional_software.SelectedItems.Item(i).ToString & "Env file( " & remaining_folder_path1 & "\*.txt" & " )not exists." & vbCrLf & "Please contact IT team.Catia started without " & chl_additional_software.SelectedItems.Item(i).ToString, vbCritical, "srp_launcher")
                End If
                If files_list1.Count > 0 Then
                    Dim other_env_file_path As String = ""
                    other_env_file_folder_path = files_list1.Item(0)
                    Dim other_app_env_variable As Dictionary(Of String, String)
                    other_app_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
                    other_app_env_variable.Clear()
                    Call ReadKeyValuesFromTextFile(other_env_file_folder_path, other_app_env_variable)
                    Call MergeDictionaries(base_file_env_variable, other_app_env_variable)
                End If
            Next
        End If

    End Function
    Public Function GetAppType(ByRef type_of_app As String)

        Dim x_string As String = ""
        x_string = Replace(tv_folder.SelectedNode.Tag, global_variable.base_folder_path & "\", "", 1, -1, CompareMethod.Text)
        Dim str_of_app() As String
        Erase str_of_app
        str_of_app = Split(x_string, "\", -1, CompareMethod.Text)
        type_of_app = str_of_app(0)

    End Function
End Class