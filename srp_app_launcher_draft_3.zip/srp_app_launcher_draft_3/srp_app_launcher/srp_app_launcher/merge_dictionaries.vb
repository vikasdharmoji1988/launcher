﻿Module merge_dictionaries
    Sub Main()
        Dim base_env_txt_file As String
        base_env_txt_file = "C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CATIAV5\BAJAJ\R32\CatENV\CATIA.V5R21.B21.txt"

        Dim base_file_env_variable As Dictionary(Of String, String)
        base_file_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        base_file_env_variable.Clear()
        Call ReadKeyValuesFromTextFile(base_env_txt_file, base_file_env_variable)

        Dim other_app_env_variable As Dictionary(Of String, String)
        other_app_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        other_app_env_variable.Clear()
        Dim other_app_txt_file_path As String = "C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\OTHER\CATIAV5\QChecker\qchecker.txt"
        Call ReadKeyValuesFromTextFile(other_app_txt_file_path, other_app_env_variable)
        Call MergeDictionaries(base_file_env_variable, other_app_env_variable)
    End Sub
    Public Sub MergeDictionaries(ByRef baseDict As Dictionary(Of String, String), ByVal otherDict As Dictionary(Of String, String))
        For Each kvp As KeyValuePair(Of String, String) In otherDict

            Dim key As String = kvp.Key
            Dim value As String = kvp.Value

            ' Case 1: Key does NOT exist → Add it
            If Not baseDict.ContainsKey(key) Then
                baseDict.Add(key, value)

            Else
                ' Case 2: Key exists → Update ONLY if second has value
                If Not String.IsNullOrWhiteSpace(value) Then
                    baseDict(key) = value
                End If
            End If

        Next
    End Sub
End Module
