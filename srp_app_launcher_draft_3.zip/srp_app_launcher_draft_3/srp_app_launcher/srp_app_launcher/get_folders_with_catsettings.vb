﻿Imports System.IO
Module get_folders_with_catsettings
    Sub MainExample()
        Dim licen_folder As String = "C:\VikasData\app_launcher\srp_app_launcher_draft_2\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CONFIG\CATLicensing"
        Dim license_list As List(Of String)
        license_list = New List(Of String)
        Call GetFoldersWithLicenseCATSettings(licen_folder, license_list)
        If license_list.Count > 0 Then
            For i = 0 To license_list.Count - 1
                MsgBox(license_list.Item(i))
            Next
        End If
    End Sub

    Public Function GetFoldersWithLicenseCATSettings(rootPath As String, ByRef result As List(Of String))

        If Not Directory.Exists(rootPath) Then
            Throw New DirectoryNotFoundException("licensing folder is not exists: " & rootPath)
        End If

        Try
            ' Get all subdirectories recursively
            Dim allDirs = Directory.GetDirectories(rootPath, "*", SearchOption.AllDirectories)
            Dim Dir
            For Each Dir In allDirs
                Try
                    ' Check if any .CATSettings file exists in this folder
                    Dim files = Directory.GetFiles(Dir, "*.CATSettings", SearchOption.TopDirectoryOnly)

                    If files.Length > 0 Then
                        result.Add(System.IO.Path.GetFileName(Dir))
                    End If

                Catch ex As Exception
                    ' Skip folders with access issues
                    Continue For
                End Try
            Next

        Catch ex As Exception
            Throw New Exception("licensing folder is not exists: " & ex.Message)
        End Try

        Return result

    End Function
End Module
