﻿Imports System.IO

Public Class frm_start
    Private Sub frm_start_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tv_folder.HideSelection = False
        tv_folder.FullRowSelect = True
        Dim rootPath As String = global_variable.base_folder_path  'your main folder path

        'tv_folder.Nodes.Clear()

        Dim rootDir As New DirectoryInfo(rootPath)

        Dim rootNode As TreeNode = tv_folder.Nodes.Add(rootDir.Name)
        rootNode.Tag = rootDir.FullName

        LoadSubDirectories(rootDir, rootNode)
        tv_folder.Focus()
    End Sub
    Private Sub LoadSubDirectories(dir As DirectoryInfo, parentNode As TreeNode)

        Dim directories() As DirectoryInfo

        Try
            directories = dir.GetDirectories()
        Catch ex As Exception
            Exit Sub
        End Try

        For Each subDir As DirectoryInfo In directories

            Dim childNode As TreeNode = parentNode.Nodes.Add(subDir.Name)
            childNode.Tag = subDir.FullName

            LoadSubDirectories(subDir, childNode)

        Next

    End Sub

    Private Sub tv_folder_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles tv_folder.AfterSelect
        global_variable.selected_node_tag = e.Node.Tag.ToString
        If IO.File.Exists(global_variable.selected_node_tag & "\license_configuration.txt") = True Then
            Dim txt_file_path As String = global_variable.selected_node_tag & "\license_configuration.txt"
            Dim lines_list As List(Of String)
            lines_list = New List(Of String)
            lines_list.Clear()
            chl_lic_configuration.Items.Clear()
            ReadTextFileLineByLine(txt_file_path, lines_list)
            If lines_list.Count > 0 Then
                For i = 0 To lines_list.Count - 1
                    chl_lic_configuration.Items.Add(lines_list.Item(i))
                Next
            End If
        End If
        If IO.File.Exists(global_variable.selected_node_tag & "\license_configuration.txt") = False Then
            chl_lic_configuration.Items.Clear()
        End If

        If IO.File.Exists(global_variable.selected_node_tag & "\additional_software.txt") = True Then
            Dim txt_file_path1 As String = global_variable.selected_node_tag & "\additional_software.txt"
            Dim lines_list1 As List(Of String)
            lines_list1 = New List(Of String)
            lines_list1.Clear()
            chl_additional_software.Items.Clear()
            ReadTextFileLineByLine(txt_file_path1, lines_list1)
            If lines_list1.Count > 0 Then
                For i = 0 To lines_list1.Count - 1
                    chl_additional_software.Items.Add(lines_list1.Item(i))
                Next
            End If
        End If
        If IO.File.Exists(global_variable.selected_node_tag & "\additional_software.txt") = False Then
            chl_additional_software.Items.Clear()
        End If

        tv_folder.Focus()
    End Sub

    Private Sub tv_folder_BeforeExpand(sender As Object, e As TreeViewCancelEventArgs) Handles tv_folder.BeforeExpand

        Dim node As TreeNode = e.Node
        Dim rootpath As String = node.Tag.ToString()
        'remove dummy node
        node.Nodes.Clear()
        Dim rootDir As New DirectoryInfo(rootpath)

        LoadSubDirectories(rootDir, node)

    End Sub



    Private Sub chl_lic_configuration_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles chl_lic_configuration.ItemCheck
        If e.NewValue = CheckState.Checked Then
            For i As Integer = 0 To chl_lic_configuration.Items.Count - 1
                If i <> e.Index Then
                    chl_lic_configuration.SetItemChecked(i, False)
                End If
            Next
        End If
    End Sub

    Private Sub frm_start_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        tv_folder.Focus()
    End Sub

    Private Sub chl_additional_software_SelectedIndexChanged(sender As Object, e As EventArgs) Handles chl_additional_software.SelectedIndexChanged
        tv_folder.Focus()
    End Sub

    Private Sub chl_lic_configuration_SelectedIndexChanged(sender As Object, e As EventArgs) Handles chl_lic_configuration.SelectedIndexChanged
        tv_folder.Focus()
    End Sub

    Private Sub butt_start_Click(sender As Object, e As EventArgs) Handles butt_start.Click

        If IO.File.Exists(global_variable.selected_node_tag & "\license_configuration.txt") = False Then
            Dim status
            status = MsgBox("Please select at least one environment from the application to start.", vbCritical, "SPR Lanucher")
            Exit Sub
        End If

        If chl_lic_configuration.CheckedItems.Count = 0 Then
            Dim status
            status = MsgBox("Please select at least one license configuration.", vbCritical, "SPR Lanucher")
            Exit Sub
        End If

        Dim bat_file_path As String = ""
        Dim bat_file_name As String = ""
        bat_file_path = global_variable.selected_node_tag
        Dim lic_bat_name As String = LCase(Replace(chl_lic_configuration.CheckedItems(0).ToString, "+", "_")) & ".bat"


    End Sub
End Class