﻿Module run_bat_file
    Sub test()
        Dim full_bat_path As String = bat_file_path & "\" & lic_bat_name & ".bat"


    End Sub
    Public Function RunBatFile(batFilePath As String) 'As Boolean
        Try
            If IO.File.Exists(batFilePath) = False Then
                MsgBox("BAT file not found : " & batFilePath, vbCritical, "SPR Launcher")
                Return False
            End If

            Dim psi As New ProcessStartInfo
            psi.FileName = "cmd.exe"
            psi.Arguments = "/c """ & batFilePath & """"
            psi.WorkingDirectory = IO.Path.GetDirectoryName(batFilePath)
            psi.UseShellExecute = True
            psi.CreateNoWindow = False

            Process.Start(psi)

            'Return True

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "Error running BAT file")
            ' Return False
        End Try
    End Function
End Module
