﻿Module exe_start
    Sub Main()
        global_variable.base_folder_path = "C:\VikasData\app_launcher\SRP"
        Dim frm_start1 As frm_start
        frm_start1 = New frm_start
        frm_start1.ShowDialog()
    End Sub
End Module
