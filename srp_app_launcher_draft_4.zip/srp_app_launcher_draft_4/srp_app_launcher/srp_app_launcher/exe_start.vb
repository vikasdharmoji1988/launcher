﻿Imports System.IO
Module exe_start
    Sub Main()
        'Dim exe_folder_path As String = System.IO.Path.GetDirectoryName(Application.ExecutablePath) & "\LAUNCHER"
        Dim exe_folder_path As String = System.IO.Path.GetDirectoryName(Application.ExecutablePath)
        Dim split_path() As String = Split(exe_folder_path, "\CONFIG", -1, CompareMethod.Text)

        Dim base_folder_path As String = split_path(0)
        'Dim base_folder_path As String = exe_folder_path
        If System.IO.Directory.Exists(base_folder_path) = False Then
            Dim status
            status = MsgBox("Below folder is not exists.Please contact IT team." & vbCrLf & base_folder_path, vbCritical, "SPR Lanucher")
            Exit Sub
        End If
        global_variable.base_folder_path = base_folder_path
        'MsgBox(global_variable.base_folder_path)
        Dim frm_start1 As frm_start
        frm_start1 = New frm_start
        frm_start1.ShowDialog()
    End Sub
End Module
