﻿Module get_q_checker_env_variable
    Sub Maintest()
        Dim v5_version As String
        Dim q_checker_folder_path As String
        Dim qchecker_env_variable As Dictionary(Of String, String) = New Dictionary(Of String, String)
        v5_version = "21"
        q_checker_folder_path = "C:\VikasData\app_launcher\srp_app_launcher_draft_5\srp_app_launcher\srp_app_launcher\bin\Debug\LAUNCHER\OTHER\catiav5\qchecker"
        qchecker_env_variable.Clear()
        Call GetQcheckerEnvVariable(v5_version, q_checker_folder_path, qchecker_env_variable)
    End Sub
    Public Function GetQcheckerEnvVariable(v5_version As String, q_checker_folder_path As String, ByRef qchecker_env_variable As Dictionary(Of String, String))
        Dim v5_version_int = CInt(v5_version)
        Dim q_checker_env_file_path As String
        If v5_version_int < 23 Then
            q_checker_env_file_path = q_checker_folder_path & "\CATEnv\Qchecker_V2.txt"
        End If

        If v5_version_int >= 23 Then
            q_checker_env_file_path = q_checker_folder_path & "\CATEnv\Qchecker_V5.txt"
        End If

        Dim CATQCHECKERPATH As String = q_checker_folder_path
        Dim folders1 As List(Of String)
        folders1 = GetTopLevelFolders(CATQCHECKERPATH)
        Dim QVER As String = ""
        For Each f In folders1
            Dim split_string() As String = Split(f, "_", -1, CompareMethod.Text)
            If UBound(split_string) > 1 Then
                Dim cv5_name_in_folder As String = Split(f, "_", -1, CompareMethod.Text)(1)


                Dim q_checker_v5_version As String = cv5_name_in_folder.Trim().Substring(cv5_name_in_folder.IndexOf("R") + 1)
                If v5_version_int = CInt(q_checker_v5_version) Then
                    QVER = f
                    Exit For
                End If
            End If

        Next

        Call ReadKeyValuesFromTextFile(q_checker_env_file_path, qchecker_env_variable)
        For Each x In qchecker_env_variable.Keys.ToList()
            If qchecker_env_variable(x) IsNot Nothing Then
                Dim value As String = qchecker_env_variable(x)
                value = value.Replace("[CATQCHECKERPATH]", CATQCHECKERPATH).Replace("[QVER]", QVER)
                qchecker_env_variable(x) = value
            End If
        Next
    End Function
End Module
