﻿Module get_env_variable_from_binaries
    Public Function GetEnvVariableFromBinaries(binaries_txt_file_path As String, ByRef env_variable As Dictionary(Of String, String))
        'Dim env_variable As Dictionary(Of String, String)
        'env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        env_variable.Clear()
        Call ReadKeyValuesFromTextFile(binaries_txt_file_path, env_variable)

    End Function
End Module
