﻿Public Class global_variable
    Public Shared base_folder_path As String
    Public Shared selected_node_tag As String

End Class
