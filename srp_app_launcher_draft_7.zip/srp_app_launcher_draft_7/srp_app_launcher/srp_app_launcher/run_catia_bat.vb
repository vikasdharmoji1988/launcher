﻿Imports System.Diagnostics
Imports System.IO
Module run_catia_bat
    Sub test()
        Dim batPath As String = "C:\temp\launch_catia.bat"
        Dim catstart As String = "C:\Program Files\Dassault\B28\win_b64\code\bin\CATSTART.exe"
        Dim envName As String = "ENV1"
        Dim envDir As String = "C:\CATEnv"

        RunCatiaBat(batPath, catstart, envName, envDir)
    End Sub
    Public Sub RunCatiaBat(ByVal batFilePath As String,
                       ByVal catstartPath As String,
                       ByVal envName As String,
                       ByVal envDir As String)

        Try
            Dim psi As New ProcessStartInfo()

            psi.FileName = batFilePath

            ' Pass arguments with proper quotes (important for spaces)
            psi.Arguments = """" & catstartPath & """ " &
                            """" & envName & """ " &
                            """" & envDir & """"

            psi.UseShellExecute = False
            psi.CreateNoWindow = True   ' Set False if you want to see CMD window

            Process.Start(psi)

        Catch ex As Exception
            MsgBox("Error running BAT file: " & ex.Message)
        End Try

    End Sub
End Module
