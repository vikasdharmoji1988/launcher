﻿Imports System.IO
Imports System.Linq

Module get_particular_files_from_folder
    Sub MainExample()
        Dim files_list As List(Of String)
        files_list = New List(Of String)
        files_list.Clear()
        GetParticularFilesFromFolder("C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CATIAV5\BAJAJ\R32\CatENV", "*.txt", files_list)
        If files_list.Count > 0 Then
            MsgBox("hi")
        End If
    End Sub


    Public Function GetParticularFilesFromFolder(folderPath As String, searchPattern As String, ByRef result As List(Of String), Optional includeSubFolders As Boolean = False)


        Try
            If Directory.Exists(folderPath) Then

                Dim optionValue As SearchOption =
                If(includeSubFolders, SearchOption.AllDirectories, SearchOption.TopDirectoryOnly)

                result = Directory.GetFiles(folderPath, searchPattern, optionValue).ToList()

            Else
                MsgBox("Folder does not exist: " & folderPath)
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try


    End Function
End Module
