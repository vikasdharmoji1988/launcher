﻿Module read_key_values_from_text_file
    Sub Mainexample()
        Dim env_variable As Dictionary(Of String, String)
        env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)

        Dim txt_file_path As String = "C:\VikasData\app_launcher\srp_app_launcher_draft_2\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CONFIG\Binaries.txt"

        Call ReadKeyValuesFromTextFile(txt_file_path, env_variable)
        For Each x In env_variable.Keys
            MessageBox.Show(x)
        Next
    End Sub
    Public Function ReadKeyValuesFromTextFile(txt_file_path As String, ByRef output_dict As Dictionary(Of String, String))
        'Dim result As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)

        On Error GoTo Errorhandler
        If Not System.IO.File.Exists(txt_file_path) Then
            Dim status = MsgBox("Error in ReadKeyValuesFromTextFile :File not found=" & txt_file_path, vbCritical, "srp_launcher")
            Exit Function
        End If

        For Each line As String In System.IO.File.ReadAllLines(txt_file_path)

            ' Skip empty lines
            If String.IsNullOrWhiteSpace(line) Then Continue For

            ' Split only on FIRST "="
            Dim parts() As String = line.Split(New Char() {"="c}, 2)

            If parts.Length = 2 Then
                Dim key As String = parts(0).Trim()
                Dim value As String = parts(1).Trim()

                ' Add or update
                output_dict(key) = value
            End If

        Next
        Exit Function
Errorhandler:
        Dim status1 = MsgBox("Error in ReadKeyValuesFromTextFile:" & Err.Description, vbCritical, "srp_app_launcher")

    End Function
End Module
