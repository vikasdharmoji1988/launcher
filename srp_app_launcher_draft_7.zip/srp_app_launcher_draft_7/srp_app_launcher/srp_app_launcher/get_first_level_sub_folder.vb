﻿Imports System.IO
Module get_first_level_sub_folder
    Sub Mainexample()
        Dim folder_list As List(Of String)
        folder_list = New List(Of String)

        Call Getfirstlevelsubfolder("C:\VikasData\app_launcher\srp_app_launcher_draft_2\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\OTHER", folder_list)

        Dim i
        For i = 0 To folder_list.Count - 1
            MsgBox(folder_list.Item(i))
        Next
    End Sub
    Public Function Getfirstlevelsubfolder(input_folder_path As String, ByRef folderlist As List(Of String))
        On Error GoTo Errorhandler
        Dim dir
        If System.IO.Directory.Exists(input_folder_path) Then
            For Each dir In Directory.GetDirectories(input_folder_path)
                folderlist.Add(Path.GetFileName(dir))
            Next
        End If
        Exit Function
Errorhandler:
        MsgBox("error in Getfirstlevelsubfolder:" & Getfirstlevelsubfolder)
    End Function

End Module
