﻿Imports System.Drawing
Module convert_jpg_to_bmp
    Sub MainTest()

    End Sub
    Public Function ConvertJpgToBmp(jpg_file_path As String, ByRef bmp_file_path As String)
        Dim folder_path As String = ""
        Dim file_name As String = ""
        If System.IO.File.Exists(jpg_file_path) = True Then
            folder_path = System.IO.Path.GetDirectoryName(jpg_file_path)
            file_name = Microsoft.VisualBasic.Replace(System.IO.Path.GetFileName(jpg_file_path), ".jpg", "", 1, -1, CompareMethod.Text)


            If folder_path <> "" And file_name <> "" Then
                If System.IO.File.Exists(folder_path & "file_name" & ".bmp") = False Then
                    Dim bmp As New System.Drawing.Bitmap(jpg_file_path)
                    Dim thumb As New Bitmap(bmp, New Size(32, 32))
                    bmp_file_path = folder_path & "file_name" & ".bmp"
                    bmp.Save(bmp_file_path)
                End If
            End If
        End If

    End Function
End Module
