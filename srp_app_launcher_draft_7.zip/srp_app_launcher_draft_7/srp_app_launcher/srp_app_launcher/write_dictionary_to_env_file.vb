﻿Imports System.IO
Module write_dictionary_to_env_file
    Sub Maintest()
        Dim base_env_txt_file As String
        base_env_txt_file = "C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CATIAV5\BAJAJ\R32\CatENV\CATIA.V5R21.B21.txt"

        Dim base_file_env_variable As Dictionary(Of String, String)
        base_file_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        base_file_env_variable.Clear()
        Call ReadKeyValuesFromTextFile(base_env_txt_file, base_file_env_variable)

        Dim other_app_env_variable As Dictionary(Of String, String)
        other_app_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        other_app_env_variable.Clear()
        Dim other_app_txt_file_path As String = "C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\OTHER\CATIAV5\QChecker\qchecker.txt"
        Call ReadKeyValuesFromTextFile(other_app_txt_file_path, other_app_env_variable)
        Call MergeDictionaries(base_file_env_variable, other_app_env_variable)
        Call AddOrUpdateKeyValue(base_file_env_variable, "licensing", "xyz")
        WriteDictionaryToEnvFile(base_file_env_variable)
    End Sub
    Public Sub WriteDictionaryToEnvFile(ByVal dict As Dictionary(Of String, String))

        If dict Is Nothing Then
            Throw New ArgumentNullException("dict")
        End If

        Dim folderPath As String = "C:\temp"
        Dim filePath As String = System.IO.Path.Combine(folderPath, "cv5_env.txt")

        ' Ensure folder exists
        If Not System.IO.Directory.Exists(folderPath) Then
            System.IO.Directory.CreateDirectory(folderPath)
        End If

        ' Explicitly delete file if it exists (optional but clear)
        If System.IO.File.Exists(filePath) Then
            System.IO.File.Delete(filePath)
        End If

        ' Create and write fresh file
        Using writer As New System.IO.StreamWriter(filePath, False)
            For Each kvp As KeyValuePair(Of String, String) In dict
                writer.WriteLine(kvp.Key & "=" & kvp.Value)
            Next
        End Using

    End Sub
End Module
