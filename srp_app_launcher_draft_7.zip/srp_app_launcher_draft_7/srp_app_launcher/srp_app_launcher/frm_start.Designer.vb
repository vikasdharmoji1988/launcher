﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_start
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.gr_application_to_start = New System.Windows.Forms.GroupBox()
        Me.tv_folder = New System.Windows.Forms.TreeView()
        Me.lbl_application_to_start = New System.Windows.Forms.Label()
        Me.gr_additional_software = New System.Windows.Forms.GroupBox()
        Me.chl_additional_software = New System.Windows.Forms.CheckedListBox()
        Me.gr_license_configuration = New System.Windows.Forms.GroupBox()
        Me.chl_lic_configuration = New System.Windows.Forms.CheckedListBox()
        Me.butt_start = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.gr_application_to_start.SuspendLayout()
        Me.gr_additional_software.SuspendLayout()
        Me.gr_license_configuration.SuspendLayout()
        Me.SuspendLayout()
        '
        'gr_application_to_start
        '
        Me.gr_application_to_start.BackColor = System.Drawing.SystemColors.MenuBar
        Me.gr_application_to_start.Controls.Add(Me.tv_folder)
        Me.gr_application_to_start.Controls.Add(Me.lbl_application_to_start)
        Me.gr_application_to_start.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gr_application_to_start.Location = New System.Drawing.Point(12, 12)
        Me.gr_application_to_start.Name = "gr_application_to_start"
        Me.gr_application_to_start.Size = New System.Drawing.Size(381, 546)
        Me.gr_application_to_start.TabIndex = 0
        Me.gr_application_to_start.TabStop = False
        '
        'tv_folder
        '
        Me.tv_folder.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tv_folder.Location = New System.Drawing.Point(6, 54)
        Me.tv_folder.Name = "tv_folder"
        Me.tv_folder.Size = New System.Drawing.Size(369, 486)
        Me.tv_folder.TabIndex = 2
        '
        'lbl_application_to_start
        '
        Me.lbl_application_to_start.AutoSize = True
        Me.lbl_application_to_start.BackColor = System.Drawing.SystemColors.Menu
        Me.lbl_application_to_start.Font = New System.Drawing.Font("Calibri", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_application_to_start.Location = New System.Drawing.Point(83, 24)
        Me.lbl_application_to_start.Name = "lbl_application_to_start"
        Me.lbl_application_to_start.Size = New System.Drawing.Size(192, 27)
        Me.lbl_application_to_start.TabIndex = 1
        Me.lbl_application_to_start.Text = "Application To Start"
        '
        'gr_additional_software
        '
        Me.gr_additional_software.Controls.Add(Me.chl_additional_software)
        Me.gr_additional_software.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gr_additional_software.Location = New System.Drawing.Point(399, 12)
        Me.gr_additional_software.Name = "gr_additional_software"
        Me.gr_additional_software.Size = New System.Drawing.Size(290, 237)
        Me.gr_additional_software.TabIndex = 1
        Me.gr_additional_software.TabStop = False
        Me.gr_additional_software.Text = "Additional Software"
        '
        'chl_additional_software
        '
        Me.chl_additional_software.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chl_additional_software.FormattingEnabled = True
        Me.chl_additional_software.Location = New System.Drawing.Point(6, 28)
        Me.chl_additional_software.Name = "chl_additional_software"
        Me.chl_additional_software.Size = New System.Drawing.Size(278, 186)
        Me.chl_additional_software.TabIndex = 2
        '
        'gr_license_configuration
        '
        Me.gr_license_configuration.Controls.Add(Me.chl_lic_configuration)
        Me.gr_license_configuration.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gr_license_configuration.Location = New System.Drawing.Point(399, 255)
        Me.gr_license_configuration.Name = "gr_license_configuration"
        Me.gr_license_configuration.Size = New System.Drawing.Size(290, 303)
        Me.gr_license_configuration.TabIndex = 2
        Me.gr_license_configuration.TabStop = False
        Me.gr_license_configuration.Text = "License Configuration"
        '
        'chl_lic_configuration
        '
        Me.chl_lic_configuration.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chl_lic_configuration.FormattingEnabled = True
        Me.chl_lic_configuration.Location = New System.Drawing.Point(6, 31)
        Me.chl_lic_configuration.Name = "chl_lic_configuration"
        Me.chl_lic_configuration.Size = New System.Drawing.Size(278, 264)
        Me.chl_lic_configuration.TabIndex = 2
        '
        'butt_start
        '
        Me.butt_start.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butt_start.Location = New System.Drawing.Point(317, 564)
        Me.butt_start.Name = "butt_start"
        Me.butt_start.Size = New System.Drawing.Size(129, 48)
        Me.butt_start.TabIndex = 3
        Me.butt_start.Text = "START"
        Me.butt_start.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'frm_start
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(702, 623)
        Me.Controls.Add(Me.butt_start)
        Me.Controls.Add(Me.gr_license_configuration)
        Me.Controls.Add(Me.gr_additional_software)
        Me.Controls.Add(Me.gr_application_to_start)
        Me.Name = "frm_start"
        Me.Text = "SPR_Launcher"
        Me.gr_application_to_start.ResumeLayout(False)
        Me.gr_application_to_start.PerformLayout()
        Me.gr_additional_software.ResumeLayout(False)
        Me.gr_license_configuration.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gr_application_to_start As GroupBox
    Friend WithEvents lbl_application_to_start As Label
    Friend WithEvents tv_folder As TreeView
    Friend WithEvents gr_additional_software As GroupBox
    Friend WithEvents chl_additional_software As CheckedListBox
    Friend WithEvents gr_license_configuration As GroupBox
    Friend WithEvents chl_lic_configuration As CheckedListBox
    Friend WithEvents butt_start As Button
    Friend WithEvents ImageList1 As ImageList
End Class
