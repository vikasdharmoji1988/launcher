﻿Module get_value_by_key
    Sub test()

    End Sub
    Function GetValueByKey(dict As Dictionary(Of String, String), key As String, ByRef value_of_key As String)

        If dict.ContainsKey(key) Then
            value_of_key = dict(key)
        Else
            value_of_key = ""   ' or return Nothing
        End If

    End Function

End Module
