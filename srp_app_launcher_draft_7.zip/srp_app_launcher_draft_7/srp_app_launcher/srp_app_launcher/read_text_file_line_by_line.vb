﻿Imports System.IO
Module read_text_file_line_by_line
    Sub MainExample()
        Dim txt_file_path As String = "C:\VikasData\app_launcher\SRP\CATIAV5\TATA\V5R22HF85\license_configuration.txt"
        Dim lines_list As List(Of String)
        lines_list = New List(Of String)
        lines_list.Clear()
        ReadTextFileLineByLine(txt_file_path, lines_list)
        If lines_list.Count > 0 Then
            For i = 0 To lines_list.Count - 1

                MsgBox(lines_list.Item(i))

            Next
        End If

    End Sub
    Public Function ReadTextFileLineByLine(txt_file_path As String, ByRef lines_List As List(Of String))

        For Each line As String In File.ReadLines(txt_file_path)
            lines_List.Add(line)
        Next
    End Function
End Module
