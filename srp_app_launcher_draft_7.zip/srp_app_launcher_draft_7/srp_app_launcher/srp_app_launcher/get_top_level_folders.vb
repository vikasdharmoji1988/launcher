﻿Imports System.IO
Module get_top_level_folders
    Sub test()
        Dim folders As List(Of String)
        folders = GetTopLevelFolders("D:\MyMainFolder")

        For Each f In folders
            Debug.Print(f)
        Next
    End Sub

    Public Function GetTopLevelFolders(ByVal folderPath As String) As List(Of String)
        Dim folderList As New List(Of String)

        Try
            If Directory.Exists(folderPath) Then
                Dim directories As String() = Directory.GetDirectories(folderPath)

                For Each dir As String In directories
                    folderList.Add(Path.GetFileName(dir)) ' Only folder name
                Next
            Else
                MsgBox("Folder path does not exist")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try

        Return folderList
    End Function
End Module
