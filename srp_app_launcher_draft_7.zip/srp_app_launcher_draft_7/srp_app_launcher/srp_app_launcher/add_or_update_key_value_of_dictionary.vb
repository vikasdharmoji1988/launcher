﻿Module add_or_update_key_value_of_dictionary
    Sub Mainexample()

        Dim base_env_txt_file As String
        base_env_txt_file = "C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\CATIAV5\BAJAJ\R32\CatENV\CATIA.V5R21.B21.txt"

        Dim base_file_env_variable As Dictionary(Of String, String)
        base_file_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        base_file_env_variable.Clear()
        Call ReadKeyValuesFromTextFile(base_env_txt_file, base_file_env_variable)

        Dim other_app_env_variable As Dictionary(Of String, String)
        other_app_env_variable = New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        other_app_env_variable.Clear()
        Dim other_app_txt_file_path As String = "C:\VikasData\app_launcher\srp_app_launcher_draft_3\srp_app_launcher\srp_app_launcher\bin\Debug\SPR\OTHER\CATIAV5\QChecker\qchecker.txt"
        Call ReadKeyValuesFromTextFile(other_app_txt_file_path, other_app_env_variable)
        Call MergeDictionaries(base_file_env_variable, other_app_env_variable)
        Call AddOrUpdateKeyValue(base_file_env_variable, "licensing", "xyz")
    End Sub
    Public Sub AddOrUpdateKeyValue(ByRef dict As Dictionary(Of String, String),
                              ByVal key As String,
                              ByVal value As String)

        If dict Is Nothing Then
            Throw New ArgumentNullException("dict")
        End If

        If dict.ContainsKey(key) Then
            ' Update existing key
            dict(key) = value
        Else
            ' Add new key-value pair
            dict.Add(key, value)
        End If

    End Sub
End Module
